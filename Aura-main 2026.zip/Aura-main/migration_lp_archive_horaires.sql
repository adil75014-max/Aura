-- ═══════════════════════════════════════════════════════════════
--  MIGRATION LP : archivage + auto-purge 6 mois + plage horaire
--  ----------------------------------------------------------------
--  À exécuter dans Supabase Studio → SQL Editor.
--  Idempotent. Trois blocs indépendants — tu peux les exécuter
--  séparément.
-- ═══════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────
--  BLOC 1 — ARCHIVAGE + AUTO-PURGE 6 MOIS
-- ─────────────────────────────────────────────────────────────────

-- 1.1 Colonnes d'archivage
ALTER TABLE public.laissez_passer
    ADD COLUMN IF NOT EXISTS archive     BOOLEAN NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS archived_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_lp_archive      ON public.laissez_passer(archive);
CREATE INDEX IF NOT EXISTS idx_lp_archived_at  ON public.laissez_passer(archived_at);
CREATE INDEX IF NOT EXISTS idx_lp_fin          ON public.laissez_passer(fin_intervention);

-- 1.2 Archive tout LP dont la fenêtre est passée (expiré) et non déjà archivé.
--     Couvre les "valide" expirés mais aussi les "en_attente"/"refuse"/"annule"
--     dont la date de fin est dépassée (ils n'ont plus lieu d'être actifs).
CREATE OR REPLACE FUNCTION public.lp_archiver_expires()
RETURNS integer AS $$
DECLARE n integer;
BEGIN
    UPDATE public.laissez_passer
       SET archive = true,
           archived_at = now()
     WHERE archive = false
       AND fin_intervention IS NOT NULL
       AND fin_intervention < now();
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n;
END;
$$ LANGUAGE plpgsql;

-- 1.3 Purge définitive des archives de plus de 6 mois.
CREATE OR REPLACE FUNCTION public.lp_purger_archives()
RETURNS integer AS $$
DECLARE n integer;
BEGIN
    DELETE FROM public.laissez_passer
     WHERE archive = true
       AND archived_at IS NOT NULL
       AND archived_at < now() - interval '6 months';
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n;
END;
$$ LANGUAGE plpgsql;

-- 1.4 Planification quotidienne via pg_cron.
--     Prérequis : activer l'extension (Dashboard → Database → Extensions → pg_cron).
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Archive chaque jour à 02:10, purge à 02:20 (heure du serveur, UTC).
SELECT cron.unschedule('lp_archiver')  WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname='lp_archiver');
SELECT cron.unschedule('lp_purger')    WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname='lp_purger');
SELECT cron.schedule('lp_archiver', '10 2 * * *', $$ SELECT public.lp_archiver_expires(); $$);
SELECT cron.schedule('lp_purger',   '20 2 * * *', $$ SELECT public.lp_purger_archives(); $$);

--  ⚠️ Si pg_cron n'est pas disponible sur ton offre, supprime le bloc 1.4 :
--  l'app appellera lp_archiver_expires() au chargement (voir front), et tu
--  pourras lancer lp_purger_archives() manuellement ou via une Edge Function.

-- 1.5 Première passe immédiate (facultatif)
-- SELECT public.lp_archiver_expires();


-- ─────────────────────────────────────────────────────────────────
--  BLOC 2 — PLAGE HORAIRE QUOTIDIENNE (réponse à la question 4)
--  Sans ces colonnes, un LP multi-jours autorise l'accès EN CONTINU
--  (nuits comprises). Avec elles, l'accès n'est ouvert que dans la
--  tranche [heure_debut, heure_fin] de CHAQUE jour de la plage.
--  NULL = pas de restriction horaire (comportement actuel conservé).
-- ─────────────────────────────────────────────────────────────────
ALTER TABLE public.laissez_passer
    ADD COLUMN IF NOT EXISTS heure_debut TIME,
    ADD COLUMN IF NOT EXISTS heure_fin   TIME;


-- ─────────────────────────────────────────────────────────────────
--  BLOC 3 — À INSÉRER DANS TA FONCTION lp_scan(...)
--  Je n'ai pas ta définition actuelle de lp_scan (elle vit dans
--  Supabase, pas dans le projet). Ajoute le contrôle ci-dessous JUSTE
--  APRÈS ton test de plage de dates (debut/fin) et AVANT de renvoyer
--  autorise = true. `lp` = la ligne laissez_passer chargée par token.
--
--  -- Heure locale Paris au moment du scan :
--  DECLARE v_now_paris timestamptz := now();
--  DECLARE v_heure time := (v_now_paris AT TIME ZONE 'Europe/Paris')::time;
--
--  -- ... ton contrôle existant : v_now_paris BETWEEN lp.debut_intervention
--  --     AND lp.fin_intervention, sinon REFUS "Hors période" ...
--
--  -- NOUVEAU : restriction horaire quotidienne
--  IF lp.heure_debut IS NOT NULL AND lp.heure_fin IS NOT NULL THEN
--      IF v_heure < lp.heure_debut OR v_heure > lp.heure_fin THEN
--          RETURN jsonb_build_object(
--              'ok', true,
--              'autorise', false,
--              'message', 'Hors plage horaire autorisée ('
--                         || to_char(lp.heure_debut,'HH24:MI') || '–'
--                         || to_char(lp.heure_fin,'HH24:MI') || ')'
--          );
--      END IF;
--  END IF;
--
--  → Si tu me colles ta fonction lp_scan actuelle, je te la réécris
--    complète avec ce contrôle intégré proprement.
-- ─────────────────────────────────────────────────────────────────

-- Vérifications
SELECT column_name FROM information_schema.columns
 WHERE table_name='laissez_passer'
   AND column_name IN ('archive','archived_at','heure_debut','heure_fin')
 ORDER BY column_name;
